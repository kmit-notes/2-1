package q2;


import java.util.*;

class PrintSpooler {

    private final int capacity;
    private final LinkedList<Job> vip = new LinkedList<>();
    private final LinkedList<Job> norm = new LinkedList<>();

    int ts = 0;
    int tp = 0;
    int vp = 0;
    int np = 0;

    int producersFinished = 0;
    int totalProducers;

    PrintSpooler(int capacity, int totalProducers) {
        this.capacity = capacity;
        this.totalProducers = totalProducers;
    }

    // PRODUCER
    public synchronized void submitJob(Job job) throws InterruptedException {

        while (vip.size() + norm.size() == capacity) {
            wait();
        }

        if (job.priority.equals("VIP"))
            vip.add(job);
        else
            norm.add(job);

        ts++;

        System.out.println("Submitted: jobId=" + job.jobId +
                " owner=" + job.owner +
                " priority=" + job.priority);

        notifyAll();
    }

    // CONSUMER
    public synchronized Job getJob() throws InterruptedException {

        while (vip.isEmpty() && norm.isEmpty()) {

            if (producersFinished == totalProducers)
                return null; // termination condition

            wait();
        }

        Job job;
        if (!vip.isEmpty()) {
            job = vip.removeFirst();
            vp++;
        } else {
            job = norm.removeFirst();
            np++;
        }

        tp++;
        notifyAll();
        return job;
    }

    public synchronized void producerDone() {
        producersFinished++;
        notifyAll();
    }

    // ADMIN SAFE METHODS
    public synchronized int totalSize() {
        return vip.size() + norm.size();
    }

    public synchronized int vipWaiting() {
        return vip.size();
    }

    public synchronized int normalWaiting() {
        return norm.size();
    }
}
class Producer extends Thread {

    PrintSpooler spooler;
    String priority;
    int count;
    static int jobCounter = 1;

    Producer(String name, PrintSpooler spooler, String priority, int count) {
        super(name);
        this.spooler = spooler;
        this.priority = priority;
        this.count = count;
    }

    public void run() {
        try {
            for (int i = 0; i < count; i++) {
                Job job = new Job(
                        jobCounter++,
                        getName(),
                        5 + i,
                        priority
                );
                spooler.submitJob(job);
                Thread.sleep(200);
            }
        } catch (Exception e) {
        }
        spooler.producerDone();
    }
}
class Printer extends Thread {

    PrintSpooler spooler;

    Printer(String name, PrintSpooler spooler) {
        super(name);
        this.spooler = spooler;
    }

    public void run() {
        try {
            while (true) {
                Job job = spooler.getJob();
                if (job == null)
                    break;

                System.out.println(getName() +
                        " printed jobId=" + job.jobId +
                        " owner=" + job.owner +
                        " pages=" + job.pages +
                        " priority=" + job.priority);

                Thread.sleep(300);
            }
        } catch (Exception e) {
        }
    }
}
class Admin extends Thread {

    PrintSpooler spooler;

    Admin(PrintSpooler spooler) {
        this.spooler = spooler;
        setDaemon(true);
    }

    public void run() {
        try {
            while (true) {
                Thread.sleep(2000);
                System.out.println("ADMIN -> SpoolerSize=" +
                        spooler.totalSize() +
                        " VIP=" + spooler.vipWaiting() +
                        " NORMAL=" + spooler.normalWaiting());
            }
        } catch (Exception e) {
        }
    }
}
public class q2 {

    public static void main(String[] args) throws Exception {

        int K = 5;   // spooler capacity
        int N = 4;   // jobs per producer

        PrintSpooler spooler = new PrintSpooler(K, 3);

        Producer p1 = new Producer("P1", spooler, "NORMAL", N);
        Producer p2 = new Producer("P2", spooler, "NORMAL", N);
        Producer p3 = new Producer("P3", spooler, "VIP", N);

        Printer a = new Printer("Printer-A", spooler);
        Printer b = new Printer("Printer-B", spooler);

        Admin admin = new Admin(spooler);

        admin.start();
        p1.start(); p2.start(); p3.start();
        a.start(); b.start();

        p1.join(); p2.join(); p3.join();
        a.join(); b.join();

        System.out.println("\n===== FINAL REPORT =====");
        System.out.println("Total jobs submitted: " + spooler.ts);
        System.out.println("Total jobs printed  : " + spooler.tp);
        System.out.println("VIP jobs printed    : " + spooler.vp);
        System.out.println("NORMAL jobs printed : " + spooler.np);
    }
}

