package q2;

class Job {
    int jobId;
    String owner;
    int pages;
    String priority; // "VIP" or "NORMAL"

    Job(int jobId, String owner, int pages, String priority) {
        this.jobId = jobId;
        this.owner = owner;
        this.pages = pages;
        this.priority = priority;
    }
}